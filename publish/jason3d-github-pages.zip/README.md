﻿# JASON 3D — GitHub Pages

This folder is the complete static site. Deploy it to `jazblue/jason3d`.

GitHub Pages URL after deployment:

`https://jazblue.github.io/jason3d/`

## Fastest fix if the page is blank or missing

1. Open the `jason3d` repository on GitHub.
2. Confirm `index.html` is in the repository root, not inside another folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Wait for the Pages deployment to finish, then open `https://jazblue.github.io/jason3d/`.

Do not open the raw HTML file on GitHub. GitHub does not render the website in the code view; it serves it through the Pages URL after deployment.
